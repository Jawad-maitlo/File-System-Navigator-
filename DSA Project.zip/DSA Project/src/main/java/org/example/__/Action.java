package org.example.__;

public class Action {
    public enum Type { CREATE, DELETE }
    private final Type type;
    private final FileSystemNode node;
    private final FileSystemNode parent; // Parent is needed for both Create (to delete) and Delete (to restore)

    public Action(Type type, FileSystemNode node, FileSystemNode parent) {
        this.type = type;
        this.node = node;
        this.parent = parent;
    }

    public Type getType() {
        return type;
    }

    public FileSystemNode getNode() {
        return node;
    }

    public FileSystemNode getParent() {
        return parent;
    }
}