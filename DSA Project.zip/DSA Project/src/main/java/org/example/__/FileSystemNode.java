package org.example.__;

import java.util.LinkedList;

public class FileSystemNode {
    private String name;
    private boolean isDirectory;
    private FileSystemNode parent;
    // Using LinkedList for children list to allow O(1) insertion/deletion at any point
    // (though we primarily use list.remove(node) which is O(N) but typical for tree structures).
    private LinkedList<FileSystemNode> children = new LinkedList<>();

    public FileSystemNode(String name, boolean isDirectory, FileSystemNode parent) {
        this.name = name;
        this.isDirectory = isDirectory;
        this.parent = parent;
    }

    public String getName() {
        return name;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public FileSystemNode getParent() {
        return parent;
    }

    public LinkedList<FileSystemNode> getChildrenList() {
        return children;
    }

    public void addChild(FileSystemNode child) {
        children.add(child);
    }
}