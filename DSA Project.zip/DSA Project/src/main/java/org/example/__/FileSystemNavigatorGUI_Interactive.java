package org.example.__;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import java.net.URL;
import java.util.*;

// Import the external classes
import org.example.__.FileSystemNode;
import org.example.__.Action;

public class FileSystemNavigatorGUI_Interactive extends Application {

    // --- Core Controls & State ---
    private final ScrollPane contentScrollPane = new ScrollPane();
    private final TilePane iconGrid = new TilePane(10, 10);
    private FileSystemNode rootNode;
    private FileSystemNode currentDirectory;
    private final Stack<Action> undoStack = new Stack<>();
    // private final Stack<Action> redoStack = new Stack<>(); // REMOVED: Redo Stack

    // --- Fields for Selection/Deletion ---
    private FileSystemNode selectedNode = null;
    private VBox selectedIconBox = null;

    private final Label pathLabel = new Label(); // NEW: Path Display

    private static final int ICON_SIZE_LARGE = 75;
    private static final int ICON_SIZE_TOOLBAR = 30;

    @Override
    public void start(Stage primaryStage) {

        try {
            // 1. Ensure your icon is in src/main/resources/assets/icon.png
            String iconPath = "Icon/icon(9).png";

            // Use Objects.requireNonNull for better error checking and loading
            Image appIcon = new Image(Objects.requireNonNull(getClass().getResourceAsStream(iconPath)));

            primaryStage.getIcons().add(appIcon);

        } catch (Exception e) {
            System.err.println("Icon Loading Error: Could not find or load image.");
            System.err.println("Check if the path is correct and the file exists in the resources directory.");
            e.printStackTrace();
        }
        setupInitialTree();
        currentDirectory = rootNode;

        HBox toolbar = setupToolbar();
        setupIconGrid();

              // --- Layout ---
        BorderPane mainLayout = new BorderPane();
        mainLayout.setTop(toolbar);
        mainLayout.setCenter(contentScrollPane);
        mainLayout.getStyleClass().add("root-pane");

        // --- Display & CSS Loading ---
        Scene scene = new Scene(mainLayout, 900, 600);
        String packagePath = getClass().getPackage().getName().replace('.', '/');
        String cssPath = "/" + packagePath + "/style.css";
        URL cssResource = getClass().getResource(cssPath);

        if (cssResource != null) {
            scene.getStylesheets().add(cssResource.toExternalForm());
        } else {
            System.err.println("CRITICAL ERROR: Could not find style.css. UI styling will be minimal.");
        }

        primaryStage.setTitle("JIMSA File Explorer");
        primaryStage.setScene(scene);
        primaryStage.show();

        listContents(currentDirectory);
        updatePathDisplay();
    }

    /** Helper to load an image or return a visible placeholder on failure. */
    private ImageView createIcon(String filename, int size) {
        ImageView imageView = new ImageView();
        imageView.setFitWidth(size);
        imageView.setFitHeight(size);
        imageView.setPreserveRatio(true);

        try {
            String packagePath = getClass().getPackage().getName().replace('.', '/');
            String absolutePath = "/" + packagePath + "/icon/" + filename;

            Image image = new Image(getClass().getResourceAsStream(absolutePath));

            if (image.isError() || image.getWidth() <= 0) {
                throw new Exception("Image is invalid or empty.");
            }
            imageView.setImage(image);

        } catch (Exception e) {
            System.err.println("Failed to load icon: " + filename + ". Using visual placeholder.");

            // Create a simple colored rectangle as a fallback graphic
            Rectangle placeholder = new Rectangle(size, size, Color.web("#444444"));
            imageView.setFitWidth(size);
            imageView.setFitHeight(size);

            StackPane placeholderPane = new StackPane(placeholder);
            placeholderPane.setPrefSize(size, size);
        }
        return imageView;
    }

    private void setupIconGrid() {
        iconGrid.setPadding(new Insets(20));
        iconGrid.setPrefColumns(5);
        iconGrid.getStyleClass().add("icon-grid");

        contentScrollPane.setContent(iconGrid);
        contentScrollPane.setFitToWidth(true);
        contentScrollPane.setFitToHeight(true);
        contentScrollPane.getStyleClass().add("content-scroll-pane");
    }

    /** Renders the current directory's children as clickable icons. **/
    private void listContents(FileSystemNode directory) {
        iconGrid.getChildren().clear();
        selectedNode = null;
        selectedIconBox = null;

        // Add a 'Go Up' icon if not at root
        if (directory.getParent() != null) {
            // Note: The parent node here is the destination, not the '..' label itself
            VBox upIcon = createGridIcon("..", true, directory.getParent());
            iconGrid.getChildren().add(upIcon);
        }

        for (FileSystemNode child : directory.getChildrenList()) {
            VBox iconNode = createGridIcon(child.getName(), child.isDirectory(), child);

            // Reapply selection state after refresh (if needed, though we clear selection here)
            // if (child == selectedNode) {
            //     iconNode.getStyleClass().add("selected-icon-box");
            //     selectedIconBox = iconNode;
            // }

            iconGrid.getChildren().add(iconNode);
        }
    }

    /** Creates a single VBox containing an icon and a label for the grid. **/
    private VBox createGridIcon(String name, boolean isDirectory, FileSystemNode node) {
        // Using generic icons for simplicity and stability based on your resource files
        String iconFile;
        if (name.equals("..")) {
            iconFile = "icon(0).png"; // FIXED: Changed from "icon().jpeg" to a valid filename.
        } else if (isDirectory) {
            iconFile = "icon(8).png"; // Directory
        } else {
            iconFile = "icon(8).png"; // File
        }

        ImageView icon = createIcon(iconFile, ICON_SIZE_LARGE);
        Label label = new Label(name);
        label.getStyleClass().add("icon-label");

        VBox iconBox = new VBox(3, icon, label);
        iconBox.setAlignment(Pos.TOP_CENTER);
        iconBox.getStyleClass().add("grid-icon-box");
        iconBox.setPrefWidth(100);
        iconBox.setPadding(new Insets(3));

        // Add click handler for SELECTION (single click) and NAVIGATION (double click)
        iconBox.setOnMouseClicked(e -> {

            if (e.getButton() == MouseButton.PRIMARY) {
                // 1. Handle Selection (Single Click)
                // FIXED: Changed incorrect check to properly allow selection of all non-parent items.
                if (!name.equals("..")) {
                    handleSelection(node, iconBox);
                }

                // 2. Handle Navigation (Double Click or Single Click '..')
                if (e.getClickCount() == 2 && node.isDirectory()) {
                    currentDirectory = node;
                    selectedNode = null;
                    listContents(currentDirectory);
                    updatePathDisplay(); // NEW: Update path after navigation
                } else if (name.equals("..") && e.getClickCount() == 1) {
                    currentDirectory = node;
                    selectedNode = null;
                    listContents(currentDirectory);
                    updatePathDisplay(); // NEW: Update path after navigation
                } else if (!isDirectory && e.getClickCount() == 2) {
                    showAlert("File Opened", "File '" + name + "' would be opened now.");
                }
            }
        });

        return iconBox;
    }

    /** Helper function to manage icon selection state. **/
    private void handleSelection(FileSystemNode node, VBox iconBox) {
        if (node.getName().equals("..")) {
            return;
        }

        if (selectedNode == node) {
            // Deselect
            selectedNode = null;
            selectedIconBox.getStyleClass().remove("selected-icon-box");
            selectedIconBox = null;
        } else {
            // Deselect previous
            if (selectedIconBox != null) {
                selectedIconBox.getStyleClass().remove("selected-icon-box");
            }
            // Select new
            selectedNode = node;
            selectedIconBox = iconBox;
            selectedIconBox.getStyleClass().add("selected-icon-box");
        }
    }


    /** Horizontal Toolbar at the top **/
    private HBox setupToolbar() {
        // --- 1. Create Buttons with Tooltips ---

        Button mkdirButton = new Button("", createIcon("icon(4).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(mkdirButton, new Tooltip("Create New Directory "));

        Button touchButton = new Button("Touch", createIcon("icon(8).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(touchButton, new Tooltip("Create New File "));

        Button rmButton = new Button("Rm", createIcon("icon(3).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(rmButton, new Tooltip("Delete Selected Item "));

        Button sortButton = new Button("Sort", createIcon("icon(7).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(sortButton, new Tooltip("Sort Current Directory Contents"));

        Button lsRButton = new Button("ls -R", createIcon("icon(1).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(lsRButton, new Tooltip("List Recursively "));

        Button findButton = new Button("Find", createIcon("icon(5).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(findButton, new Tooltip("Find File/Directory (BFS)"));

        Button undoButton = new Button("Undo", createIcon("icon(6).jpeg", ICON_SIZE_TOOLBAR));
        Tooltip.install(undoButton, new Tooltip("Undo Last Action"));


        // --- 2. Remove Text and Set Actions ---

        // Remove text and only use graphic
        mkdirButton.setText(null);
        touchButton.setText(null);
        rmButton.setText(null);
        sortButton.setText(null);
        lsRButton.setText(null);
        findButton.setText(null);
        undoButton.setText(null);

        mkdirButton.fire();
        touchButton.fire();
        rmButton.fire();
        sortButton.fire();
        lsRButton.fire();
        findButton.fire();
        undoButton.fire();

        //mkdirButton.blendModeProperty();



        // Set Actions
        mkdirButton.setOnAction(e -> handleMkdir());
        touchButton.setOnAction(e -> handleTouch());
        rmButton.setOnAction(e -> handleRm());
        sortButton.setOnAction(e -> handleSort());
        lsRButton.setOnAction(e -> handleLsR());
        findButton.setOnAction(e -> handleFind());
        undoButton.setOnAction(e -> handleUndo());

        // --- 3. Assemble Toolbar ---

        HBox toolbarButtons = new HBox(10);
        toolbarButtons.getChildren().addAll(
                mkdirButton, touchButton, rmButton, new Separator(),
                sortButton, new Separator(),
                lsRButton, findButton, new Separator(),
                undoButton // REDO BUTTON REMOVED
        );

        // Setup Path Label
        pathLabel.getStyleClass().add("path-label");
        pathLabel.setText("Current Path:root /"); // Initial text

        HBox toolbar = new HBox(15, toolbarButtons, pathLabel); // Combine buttons and path label
        toolbar.getStyleClass().add("top-toolbar");
        toolbar.setPadding(new Insets(8, 15, 8, 15));
        toolbar.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(pathLabel, Priority.ALWAYS); // Path label takes remaining space

        return toolbar;
    }

    /** NEW: Helper to update the path display label. **/
    private void updatePathDisplay() {
        if (currentDirectory == null) return;

        LinkedList<String> pathSegments = new LinkedList<>();
        FileSystemNode current = currentDirectory;

        // Traverse up the tree to build the path segments
        while (current != null) {
            pathSegments.addFirst(current.getName().equals("/Root") ? "" : current.getName());
            current = current.getParent();
        }

        // Construct the path string, handling the root case
        String path = String.join("/", pathSegments);
        path = path.replace("//", "/");
        if (path.isEmpty()) path = "/";

        // Remove the hardcoded "/Root" if it appears at the beginning of the path
        if (path.startsWith("/Root")) path = path.substring(5);
        if (path.isEmpty()) path = "/";

        pathLabel.setText("Current Path:root" + path);
    }

    /** NEW: Helper to check for duplicate names in the current directory. **/
    private boolean isNameDuplicate(String name, FileSystemNode directory) {
        for (FileSystemNode child : directory.getChildrenList()) {
            if (child.getName().equalsIgnoreCase(name.trim())) {
                return true;
            }
        }
        return false;
    }


    // --- DSA Core Methods (Mkdir, Touch, Rm, Undo, Sort, LsR, Find) ---
    static int c=0;
    private void handleMkdir() {
        TextInputDialog dialog = new TextInputDialog("New Folder" + "(" + c +")");
        dialog.setTitle("Create Directory");
        dialog.setHeaderText("Enter name for the new directory:");
        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> {
            String trimmedName = name.trim();
            if (trimmedName.isEmpty()) return;

            if (isNameDuplicate(trimmedName, currentDirectory)) { // ERROR CHECK
                showAlert("Creation Error", "A directory or file with the name '" + trimmedName + "' already exists here.");
                return;
            }

            FileSystemNode newNode = new FileSystemNode(trimmedName, true, currentDirectory);
            currentDirectory.addChild(newNode);
            c++;
            undoStack.push(new Action(Action.Type.CREATE, newNode, currentDirectory));
            // redoStack.clear(); // REDO LOGIC REMOVED
            listContents(currentDirectory);
            updatePathDisplay();
        });
    }

    private void handleTouch() {
        TextInputDialog dialog = new TextInputDialog("New File.txt");
        dialog.setTitle("Create File");
        dialog.setHeaderText("Enter name for the new file:");
        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> {
            String trimmedName = name.trim();
            if (trimmedName.isEmpty()) return;

            if (isNameDuplicate(trimmedName, currentDirectory)) { // ERROR CHECK
                showAlert("Creation Error", "A directory or file with the name '" + trimmedName + "' already exists here.");
                return;
            }

            FileSystemNode newNode = new FileSystemNode(trimmedName, false, currentDirectory);
            currentDirectory.addChild(newNode);
            undoStack.push(new Action(Action.Type.CREATE, newNode, currentDirectory));
            // redoStack.clear(); // REDO LOGIC REMOVED
            listContents(currentDirectory);
            updatePathDisplay();
        });
    }

    private void handleRm() {
        if (selectedNode == null) {
            showAlert("Deletion Error (rm)", "Please **single-click** an icon (folder or file) to select it first, then click the trash can (Rm button).");
            return;
        }

        if (selectedNode.getName().equals("..")) {
            showAlert("Deletion Error (rm)", "Cannot delete the 'Go Up' link.");
            return;
        }

        if (selectedNode.getName() == "New Folder" + "(" + (c-1) +")") {
            c--;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Deletion");
        confirm.setHeaderText("Are you sure you want to delete '" + selectedNode.getName() + "'?");
        confirm.setContentText("This action will remove the item.");

        Optional<ButtonType> result = confirm.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            FileSystemNode nodeToDelete = selectedNode;
            FileSystemNode parent = nodeToDelete.getParent();

            parent.getChildrenList().remove(nodeToDelete);

            // Push the inverse action (DELETE) for Undo
            undoStack.push(new Action(Action.Type.DELETE, nodeToDelete, parent));
            // redoStack.clear(); // REDO LOGIC REMOVED

            // Clear selection and refresh
            selectedNode = null;
            selectedIconBox = null;
            listContents(currentDirectory);
            showAlert("Deletion Complete", "Deleted '" + nodeToDelete.getName() + "'.");
            updatePathDisplay();
        }
    }

    private void handleUndo() {
        if (undoStack.isEmpty()) {
            showAlert("Undo Error", "No operations to undo. The stack is empty.");
            return;
        }
        Action actionToUndo = undoStack.pop();
        FileSystemNode node = actionToUndo.getNode();
        FileSystemNode parent = actionToUndo.getParent();

        if (actionToUndo.getType() == Action.Type.CREATE) {
            // Revert CREATE: Remove the created node
            parent.getChildrenList().remove(node);
            showAlert("Undo Complete", "Reversed: Deleted the created item '" + node.getName() + "'.");
        } else if (actionToUndo.getType() == Action.Type.DELETE) {
            // Revert DELETE: Restore the deleted node
            parent.addChild(node);
            showAlert("Undo Complete", "Reversed: Restored the deleted item '" + node.getName() + "'.");
        }

        // Clear selection and refresh view
        if (selectedNode == node) {
            selectedNode = null;
            selectedIconBox = null;
        }

        listContents(currentDirectory);
        updatePathDisplay(); // Update path display
    }

    // handleRedo() method removed

    private void handleSort() {
        currentDirectory.getChildrenList().sort((n1, n2) -> {
            if (n1.isDirectory() && !n2.isDirectory()) {
                return -1;
            }
            if (!n1.isDirectory() && n2.isDirectory()) {
                return 1;
            }
            return n1.getName().compareToIgnoreCase(n2.getName());
        });
        listContents(currentDirectory);
        showAlert("Sorting Done", "Contents sorted by Type then Name.");
    }

    private void lsR_DFS(FileSystemNode node, StringBuilder sb, int depth) {
        String indent = " ".repeat(depth * 3);
        sb.append(indent).append("- ").append(node.getName());
        if (node.isDirectory()) {
            sb.append("/");
        }
        sb.append("\n");

        for (FileSystemNode child : node.getChildrenList()) {
            lsR_DFS(child, sb, depth + 1);
        }
    }

    private void handleLsR() {
        StringBuilder sb = new StringBuilder("Recursive Listing (DFS):\n");
        lsR_DFS(currentDirectory, sb, 0);
        showAlert("Feature: ls -R (DFS)", sb.toString());
    }

    private FileSystemNode find_BFS(FileSystemNode startNode, String targetName) {
        Queue<FileSystemNode> queue = new LinkedList<>();
        queue.add(startNode);

        while (!queue.isEmpty()) {
            FileSystemNode current = queue.poll();

            if (current.getName().equalsIgnoreCase(targetName)) {
                return current;
            }

            for (FileSystemNode child : current.getChildrenList()) {
                queue.add(child);
            }
        }
        return null;
    }

    private void handleFind() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Find File (BFS)");
        dialog.setHeaderText("Enter name to search for:");

        dialog.showAndWait().ifPresent(targetName -> {
            if (!targetName.trim().isEmpty()) {
                // We start the search from the root of the entire file system for a more complete search
                FileSystemNode result = find_BFS(rootNode, targetName.trim());

                if (result != null) {
                    // Trace the path to the found node
                    LinkedList<String> pathSegments = new LinkedList<>();
                    FileSystemNode current = result;
                    while (current != null) {
                        pathSegments.addFirst(current.getName().equals("/Root") ? "" : current.getName());
                        current = current.getParent();
                    }
                    String path = String.join("/", pathSegments).replace("//", "/");
                    if (path.startsWith("/Root")) path = path.substring(5);
                    if (path.isEmpty()) path = "/";

                    showAlert("Find Successful (BFS)", "Found '" + result.getName() + "' at path: " + path);
                } else {
                    showAlert("Find Failed (BFS)", "Could not find file or directory named '" + targetName + "' anywhere in the file system.");
                }
            }
        });
    }

    // --- Utility Methods (Initial Tree Setup and Alerts) ---

    private void setupInitialTree() {
        rootNode = new FileSystemNode("/Root", true, null);
        FileSystemNode userDir = new FileSystemNode("Users", true, rootNode);
        FileSystemNode docsDir = new FileSystemNode("Documents", true, userDir);
        FileSystemNode srcDir = new FileSystemNode("Source", true, rootNode);
        FileSystemNode tempFile = new FileSystemNode("README.txt", false, rootNode);

        rootNode.addChild(userDir);
        rootNode.addChild(srcDir);
        rootNode.addChild(tempFile);
        userDir.addChild(docsDir);

        docsDir.addChild(new FileSystemNode("Report.docx", false, docsDir));
        docsDir.addChild(new FileSystemNode("Backup.zip", false, docsDir));
        srcDir.addChild(new FileSystemNode("main.java", false, srcDir));
        srcDir.addChild(new FileSystemNode("config.xml", false, srcDir));
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.getDialogPane().getStyleClass().add("root-pane");
        alert.showAndWait();
    }

    public static void main(String[] args) {

        launch(args);
    }
}
